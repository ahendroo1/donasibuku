@extends('layouts')
@section('content')
<!-- content -->
<div class="bg-white">
	<div class="box-container" id="box-container">

		<div class="title-content">
			<h1>Tentang Direktorat PMPK</h1>
			<div class="center-line"></div>
		</div>

		<div class="container">
			<div class="col-sm-12">
				<div class="list-berita-page">
                    <p class="m-t-20 ">
						Direktorat Pendidikan Masyarakat dan Pendidikan Khusus merupakan unit organisasi Direktorat Jenderal Pendidikan Anak Usia Dini, Pendidikan Dasar,dan Pendidikan Menengah yang mengemban amanat dalam memajukan pembangunan SDM melalui usaha bersama semua anak bangsa untuk meningkatkan mutu pendidikan dan memajukan kebudayaan di bidang pendidikan keaksaraan, pendidikan kesetaraan, dan pendidikan khusus.
                    </p>
				</div>
			</div>
			 
		</div>
	</div>
</div>
@endsection