@include(header)

<div class="wrapper-on-page">
	<div class="container">
		<div class="frame-white ta-center">
			<div class="say-thank">TERIMAKASIH</div>
			<div class="border-tbm"><span></span></div>
			<div class="message">
				Donasi Berhasil Dilakukan<br>
				Silahkan Melakukan Transaksi Max 8 Jam Setelah Melakukan Donasi
			</div>
			<div class="quote">
				Mari Ciptakan Generasi Yang lebih Baik
			</div>
			<div>
				<a href="{{url('/profile/riwayat-donasi')}}">Cek Riwayat Donasi</a>
			</div>
		</div>	
	</div>
</div>

@include(footer)